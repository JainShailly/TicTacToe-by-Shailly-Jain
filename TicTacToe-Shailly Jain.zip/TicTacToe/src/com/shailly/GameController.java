package com.shailly;

import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class GameController {

    private boolean isSingle ;
    private int moveNumber;
    private boolean gameOver;
    // move number is even for X and odd for O

    private String[] marks;
    private List<Rectangle> activeRectangles;

    @FXML
    public Rectangle position1, position2, position3,position4,position5,position6,position7,position8,position9;

    @FXML
    public GridPane gridPane;

    @FXML
    public void initialize(){
        isSingle = false;
        gameOver = false;
        moveNumber = 0;
        marks = new String[9];
        for(int i = 0 ; i < 9 ; ++i)
            marks[i] = " ";

        activeRectangles = new ArrayList<>();
        activeRectangles.add(position1);
        activeRectangles.add(position2);
        activeRectangles.add(position3);
        activeRectangles.add(position4);
        activeRectangles.add(position5);
        activeRectangles.add(position6);
        activeRectangles.add(position7);
        activeRectangles.add(position8);
        activeRectangles.add(position9);
    }


    @FXML
    public void handleMouseClicked(Event e){
        Rectangle rectangle = (Rectangle) e.getSource();
        makeMove(rectangle);

        // if it is a single player then make a random move
        if(isSingle && !gameOver){
            Random random = new Random();
            int index = random.nextInt(activeRectangles.size());
            makeMove(activeRectangles.get(index));

        }

    }

    private void makeMove(Rectangle rectangle){
        gridPane.getChildren().remove(rectangle);
        activeRectangles.remove(rectangle);

        String mark  = moveNumber%2 != 0 ? "O" : "X";
        Paint paint = moveNumber%2 !=0 ? Paint.valueOf("blue") : Paint.valueOf("red");
        Label label = new Label(mark);
        label.setPrefWidth(100.0);
        label.setPrefHeight(100.0);
        label.setAlignment(Pos.CENTER);
        label.setFont(new Font("Times New Roman italic",40));
        label.setTextFill(paint);

        if(rectangle.equals(position1)){
            gridPane.add(label,0,0);
            marks[0] = mark;
        }else if(rectangle.equals(position2)){
            gridPane.add(label,2,0);
            marks[1] = mark;
        }else if(rectangle.equals(position3)){
            gridPane.add(label,4,0);
            marks[2] = mark;
        }else if(rectangle.equals(position4)){
            gridPane.add(label,0,2);
            marks[3] = mark;
        }else if(rectangle.equals(position5)){
            gridPane.add(label,2,2);
            marks[4] = mark;
        }else if(rectangle.equals(position6)){
            gridPane.add(label,4,2);
            marks[5] = mark;
        }else if(rectangle.equals(position7)){
            gridPane.add(label,0,4);
            marks[6] = mark;
        }else if(rectangle.equals(position8)){
            gridPane.add(label,2,4);
            marks[7] = mark;
        }else if(rectangle.equals(position9)){
            gridPane.add(label,4,4);
            marks[8] = mark;
        }

        moveNumber++;
        getWinner();
    }

    public void getWinner(){
        String winner = "";
        if( marks[0].equals(marks[1]) && marks[0].equals(marks[2]) && !marks[0].equals(" ") ){
            if(isSingle){
                winner = marks[0].equals("X") ? "You" : "Computer" ;
            }else {
                winner = marks[0].equals("X") ? "Player1" : "Player2";
            }
        }else if( marks[3].equals(marks[4]) && marks[3].equals(marks[5]) && !marks[3].equals(" ") ){
            if(isSingle){
                winner = marks[3].equals("X") ? "You" : "Computer" ;
            }else {
                winner = marks[3].equals("X") ? "Player1" : "Player2";
            }
        }else if( marks[6].equals(marks[7]) && marks[6].equals(marks[8]) && !marks[6].equals(" ") ){
            if(isSingle){
                winner = marks[6].equals("X") ? "You" : "Computer" ;
            }else {
                winner = marks[6].equals("X") ? "Player1" : "Player2";
            }
        }else if( marks[0].equals(marks[3]) && marks[0].equals(marks[6]) && !marks[0].equals(" ") ){
            if(isSingle){
                winner = marks[0].equals("X") ? "You" : "Computer" ;
            }else {
                winner = marks[0].equals("X") ? "Player1" : "Player2";
            }
        }else if( marks[1].equals(marks[4]) && marks[1].equals(marks[7]) && !marks[1].equals(" ") ){
            if(isSingle){
                winner = marks[1].equals("X") ? "You" : "Computer" ;
            }else {
                winner = marks[1].equals("X") ? "Player1" : "Player2";
            }
        }else if( marks[2].equals(marks[5]) && marks[2].equals(marks[8]) && !marks[2].equals(" ") ){
            if(isSingle){
                winner = marks[2].equals("X") ? "You" : "Computer" ;
            }else {
                winner = marks[2].equals("X") ? "Player1" : "Player2";
            }
        }else if( marks[0].equals(marks[4]) && marks[0].equals(marks[8]) && !marks[0].equals(" ") ){
            if(isSingle){
                winner = marks[0].equals("X") ? "You" : "Computer" ;
            }else {
                winner = marks[0].equals("X") ? "Player1" : "Player2";
            }
        }else if( marks[2].equals(marks[4]) && marks[2].equals(marks[6]) && !marks[2].equals(" ") ){
            if(isSingle){
                winner = marks[2].equals("X") ? "You" : "Computer" ;
            }else {
                winner = marks[2].equals("X") ? "Player1" : "Player2";
            }
       }
        

        if(!winner.equals("")){
            // somebody won the match
            String msg = "Hurrah!!\n" +
                    winner + " won this match.\n";
            showAlert(winner+" won",msg);
            gameOver = true;

            // make all the slots inactive or delete all the rectangles
            for(int i = 0 ; i < activeRectangles.size(); ++i)
                gridPane.getChildren().remove(activeRectangles.get(i));

        }else if(moveNumber == 9){
            // all the 9 moves are made and no body wins
            String msg = "Nobody wins the game. It is a tie.\n" +
                    "Both of you played well.\n" +
                    "Good Luck next time. Cheers!!";
            showAlert("TicTacToe- Game Tie",msg);
            gameOver = true;
        }


    }

    public void showAlert(String title, String msg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    public void settPlayerNumber(boolean single){
        isSingle = single;

    }

}
