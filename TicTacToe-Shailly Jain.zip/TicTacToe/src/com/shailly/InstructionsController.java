package com.shailly;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class InstructionsController {

    String text = "Tic-Tac-Toe (also known as noughts and crosses or Xs and Os) is a paper and pencil game for" +
            " two players, X and O, who takes turn marking the spaces in a 3x3 grid. " +
            "The player who succeeds in placing three of their marks in a horizontal," +
            " vertical or diagonal rows wins the game." +
            "\nYou can click the mouse button to place your mark.\n " +
            "If you are playing against the computer then Computer's mark is O(Nought)" +
            " and your mark is X(Cross) and you will be given the first chance to make your move.\n" +
            " If it is a two player game then Player1 will get mark of X(Cross) and Player2 will " +
            "get mark of O(Nought).";

    @FXML
    public TextArea textArea;

    @FXML
    public void initialize(){
        textArea.setText(text);
    }

}
