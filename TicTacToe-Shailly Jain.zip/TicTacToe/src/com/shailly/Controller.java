package com.shailly;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Paint;

import java.io.IOException;

public class Controller {

    @FXML
    public Button onePlayerButton, twoPlayerButton,instructionsButton,quitButton;

    @FXML
    public void initialize(){

        try{
            onePlayerButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("onePlayerIcon.jpg"))));
        }catch(Exception e){
            System.out.println("Could not load the file onePlayerIcon.jpg");
        }

        try{
            twoPlayerButton.setGraphic(new ImageView( new Image(getClass().getResourceAsStream("twoPlayerIcon.jpg"))));
        }catch(Exception e){
            System.out.println("Could not load the file twoPlayerIcon.jpg");
        }
        try{
            instructionsButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Instructions.jpg"))));
        }catch(Exception e){
            System.out.println("Could not load the file Instructions.jpg");
        }
        try{
            quitButton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("quitIcon.jpg"))));
        }catch(Exception e){
            System.out.println("Could not load the file quitIcon.jpg");
        }
    }
    @FXML
    public void handleMouseEnter(Event e){
        Button button = (Button)e.getSource();
        button.setScaleX(1.2);
        button.setScaleY(1.2);
        button.setTextFill(Paint.valueOf("red"));
    }

    @FXML
    public void handleMouseExit(Event e){
        Button button = (Button)e.getSource();
        button.setScaleX(1.0);
        button.setScaleY(1.0);
        button.setTextFill(Paint.valueOf("blue"));
    }
    @FXML
    public void playWithComputer(){
       setGameScreen(true);
    }

    @FXML
    public void twoPlayer(){
        setGameScreen(false);
    }

    @FXML
    public void handleExit(){
        Platform.exit();
    }

    @FXML
    public void handleInformation(){
        Dialog<ButtonType> dialog = new Dialog<>();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Instruction.fxml"));
        try{
            dialog.getDialogPane().setContent(loader.load());
        }catch(IOException e){
            System.out.println("Could not load the file Instruction.fxml");
        }
        //file loaded successfully
        dialog.setTitle("TicTacToe - Instructions");
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.showAndWait();
    }

    @FXML
    public void setGameScreen(boolean isSingle){
        Dialog<ButtonType> dialog = new Dialog<>();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("GameWindow.fxml"));
        try{
            dialog.getDialogPane().setContent(loader.load());
        }catch(IOException e){
            System.out.println("Could not load the file GameWindow.fxml");
            return;
        }

        // file loaded successfully
        if(isSingle)
            dialog.setTitle("TicTacToe- Computer v/s Player");
        else
            dialog.setTitle("TicTacToe- Player1 v/s Player2");
        dialog.getDialogPane().setPrefSize(600.0,600.0);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.FINISH,ButtonType.CLOSE);
        dialog.getDialogPane().setBackground(new Background(new BackgroundFill(Paint.valueOf("white"),CornerRadii.EMPTY, Insets.EMPTY)));
        ((GameController)loader.getController()).settPlayerNumber(isSingle);
        dialog.showAndWait();
    }
}
